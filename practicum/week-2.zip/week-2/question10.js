/*
Given an integer n, return difference between the maximum and the minimum of its digits.


Example:
input: 472
output: 7 - 2 = 5
*/

var maxMinusMin = function(n) {
    let str =n.toString();
    let myArray= new Array
    for(char in str){
        myArray.push(parseInt(char))
    

    }
    return (myArray.max()-myArray.min())




};